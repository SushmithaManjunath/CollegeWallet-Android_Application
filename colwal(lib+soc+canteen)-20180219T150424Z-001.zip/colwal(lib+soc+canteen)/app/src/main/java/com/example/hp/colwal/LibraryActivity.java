package com.example.hp.colwal;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class LibraryActivity extends Activity {

    Button lb1, lb2;
    EditText e1, e2, e3, e4, e5, e6, e7;
    String name, usn, passwd, pno, email, branch, sem;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_library);
        Intent i = getIntent();
        usn = i.getStringExtra("usn");
        addListenerOnButton();


    }

    public void addListenerOnButton() {

        final Context context = this;

        lb1 = (Button) findViewById(R.id.button13);
        lb2 = (Button) findViewById(R.id.button14);


        lb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, GbbActivity.class);
                intent.putExtra("usn", usn);
                startActivity(intent);

            }

        });

        lb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, LendingActivity.class);
                intent.putExtra("usn", usn);
                startActivity(intent);

            }

        });
    }
}