package com.example.hp.colwal;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class canteenActivity extends Activity {

    Button cb1, cb2, cb3, cb4;
    EditText e1, e2, e3, e4, e5, e6, e7;
    String name, usn, passwd, pno, email, branch, sem;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_canteen);
        Intent i = getIntent();
        usn = i.getStringExtra("usn");
        addListenerOnButton();

        
    }

    public void addListenerOnButton() {

        final Context context = this;

        cb1 = (Button) findViewById(R.id.button8);
        cb2 = (Button) findViewById(R.id.button9);
        cb3 = (Button) findViewById(R.id.button10);
        cb4 = (Button) findViewById(R.id.button11);

        cb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, orderActivity.class);
                intent.putExtra("usn",usn);
                startActivity(intent);

            }

        });

        cb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, cancelActivity.class);
                intent.putExtra("usn",usn);
                startActivity(intent);

            }

        });
        cb3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, viewActivity.class);
                intent.putExtra("usn",usn);
                startActivity(intent);

            }

        });
        cb4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, historyActivity.class);
                intent.putExtra("usn",usn);
                startActivity(intent);

            }

        });
    }
}