package com.example.hp.colwal;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class modulesActivity extends Activity {

    Button cb,hb,lb1,ab;
    EditText e1, e2, e3, e4, e5, e6, e7;
    String name, usn, passwd, pno, email, branch, sem;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modules);
        Intent i = getIntent();
        usn = i.getStringExtra("usn");
        addListenerOnButton();
    }

    public void addListenerOnButton() {

        final Context context = this;

        cb = (Button) findViewById(R.id.button3);
        hb = (Button) findViewById(R.id.button5);
        lb1 = (Button) findViewById(R.id.button6);
        ab = (Button) findViewById(R.id.button7);

        cb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, canteenActivity.class);
                intent.putExtra("usn",usn);
                startActivity(intent);

            }

        });

        hb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, orderActivity.class);
                startActivity(intent);

            }

        });
        lb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, LibraryActivity.class);
                intent.putExtra("usn",usn);
                startActivity(intent);

            }

        });
        ab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, societyActivity.class);
                intent.putExtra("usn",usn);
                startActivity(intent);

            }

        });
    }
}
