package com.example.hp.colwal;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import org.apache.http.client.ClientProtocolException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Array;
import java.net.URL;
import java.net.URLConnection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import android.app.AlertDialog;
import android.text.InputType;
import android.content.DialogInterface;
import android.widget.RelativeLayout;



public class sorderActivity extends ActionBarActivity {
    private Spinner spinner, spinner2;
    LinearLayout linearMain;
    //CheckBox checkBox[];
    String usn,datas;
    Button b1,submit;
    int j = 0, i;
    String types, s, sd,items;
    Array a;
    Button add;
    Bitmap bitmap1;
    CheckBox checkBox[];
    TextView tvw[];
    int ocnt=0;
    RelativeLayout rl;
    String itstr[];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sorder);
        linearMain=(LinearLayout) findViewById(R.id.rel1);
        addListenerOnButton();
        add= new Button(this);
        submit=new Button(this);
        //txtView=new TextView(this);
        checkBox=new CheckBox[200];
        tvw=new TextView[200];
        itstr=new String[200];
        //add.setOnClickListener(this);
        // printmyname();

        add = (Button)findViewById(R.id.button12);
        // txtView=(TextView)findViewById(R.id.textView13);

        submit = (Button)findViewById(R.id.button8);
        submit.setOnClickListener(getOnClickDoSomething(b1));
        Intent i = getIntent();
        usn = i.getStringExtra("usn");
        try {
            gettypes();
        } catch (Exception e) {
        }
    }
    View.OnClickListener getOnClickDoSomething(final Button button) {
        return new View.OnClickListener()
        { public void onClick(View v) {
                try {
                    recieveOTP();
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        };
    }

    public void addListenerOnButton() {
        final String NULL="";

        final Context context = this;

        add = (Button) findViewById(R.id.button12);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    addhandle();
                }
                catch(Exception e){ }
                //orderActivity.this.addhandle();
            }
        });
    }
    public  void addhandle()
    {
        String add_items = spinner.getSelectedItem().toString();
        String add_items2 = spinner2.getSelectedItem().toString();
        EditText add_quantity=(EditText)findViewById(R.id.editText12);
        checkBox[ocnt]=new CheckBox(this);
        checkBox[ocnt].setChecked(true);
        tvw[ocnt]=new TextView(this);
        tvw[ocnt].setText(add_items2+"-"+add_quantity.getText().toString());
        linearMain.addView(checkBox[ocnt]);
        linearMain.addView(tvw[ocnt]);
        itstr[ocnt]=new String(add_items+"-"+add_items2+"-"+add_quantity.getText().toString()+"-");
        ocnt++;

    }
       /* add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {


              //  txtView.setText(txtView.getText().toString()+" " +add_items+"-"+add_items2+"-"+add_quantity.getText().toString()+"-");

            }

        });*/



    private void gettypes() throws InterruptedException {


        // Connect with a server is a time consuming process.
        //Therefore we use AsyncTask to handle it
        // From the three generic types;
        //First type relate with the argument send in execute()
        //Second type relate with onProgressUpdate method which I haven't use in this code
        //Third type relate with the return type of the doInBackground method, which also the input type of the onPostExecute method
        class HttpGetAsyncTask extends AsyncTask<String, Void, String> {


            @Override
            protected String doInBackground(String... params) {

                // As you can see, doInBackground has taken an Array of Strings as the argument
                //We need to specifically get the givenUsername and givenPassword

                // Create an intermediate to connect with the Internet
                //HttpClient httpClient = new DefaultHttpClient();

                // Sending a GET request to the web page that we want
                // Because of we are sending a GET request, we have to pass the values through the URL
                //HttpGet httpGet = new HttpGet("http://jnnce.ac.in/cse/atd.php");


                try {
                    String link = "http://mwallete.esy.es/wallette/society.php";
                    //Toast.makeText(getApplicationContext(), v.toString(),Toast.LENGTH_LONG).show();


                    //e1=(EditText)findViewById(R.id.editText);

                    String data = "usn=" + usn;
                    // String data="usn=ased";
                    // "&branch="+branch+"&email="+email+"&pno="+pno+"&sem="+sem;
                    //Toast.makeText(getApplicationContext(),data,Toast.LENGTH_LONG).show();
                    //txtLat=(TextView) findViewById(R.id.textview1);
                    //txtLat.setText(link);
                    URL url = new URL(link);
                    URLConnection conn = url.openConnection();
                    conn.setDoOutput(true);

                    OutputStreamWriter wr = new OutputStreamWriter
                            (conn.getOutputStream());
                    wr.write(data);
                    wr.flush();

                    BufferedReader reader = new BufferedReader
                            (new InputStreamReader(conn.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line = null;
                    // Read Server Response
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();


                } catch (ClientProtocolException cpe) {
                    System.out.println("Exceptionrates caz of httpResponse :" + cpe);
                    s = "e1";
                    cpe.printStackTrace();
                    //  Toast.makeText(getApplicationContext(), cpe.toString(),Toast.LENGTH_LONG).show();
                } catch (IOException ioe) {
                    System.out.println("Secondption generates caz of httpResponse :" + ioe);
                    s = ioe.toString();
                    ioe.printStackTrace();
//                    Toast.makeText(getApplicationContext(), ioe.toString(),Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    //Toast.makeText(getApplicationContext(), e.toString(),Toast.LENGTH_LONG).show();
                }

                return s;
            }

            // Argument comes for this method according to the return type of the doInBackground() and
            //it is the third generic type of the AsyncTask
            @Override
            protected void onPostExecute(String result) {
                super.onPostExecute(result);
                //if(result.length()>0)
                s = result;

                //Toast.makeText(getApplicationContext(), "HTTP GET is working...", Toast.LENGTH_LONG).show();
                sorderActivity.this.donext();
                //orderActivity.this.donext1();
			/*	if(result.equals("working")){
					Toast.makeText(getApplicationContext(), "HTTP GET is working...", Toast.LENGTH_LONG).show();
				}else{
					Toast.makeText(getApplicationContext(), "Invalid...", Toast.LENGTH_LONG).show();
				}	*/
            }
        }

        // Initialize the AsyncTask class
        try {
            HttpGetAsyncTask httpGetAsyncTask = new HttpGetAsyncTask();
            // Parameter we pass in the execute() method is relate to the first generic type of the AsyncTask
            // We are passing the connectWithHttpGet() method arguments to that
            httpGetAsyncTask.execute();
        } catch (Exception e) {
            //t1 = (TextView) findViewById(R.id.t1);
            //t1.setText(e.toString());
            Toast.makeText(getApplicationContext(), "ss", Toast.LENGTH_LONG).show();
        }

    }


    public void donext() {

        // Toast.makeText(getApplicationContext(),s, Toast.LENGTH_LONG).show();
        spinner = (Spinner) findViewById(R.id.spinner);
        // spinner2 = (Spinner) findViewById(R.id.spinner2);
        ArrayAdapter<String> adapter;
        List<String> list;


        list = new ArrayList<String>();
        String parts[] = s.split("#");
        for (int i = 0; i < parts.length; i++)
            list.add(parts[i]);

        /*for(int i=1;i<3;i++)
            list.add(parts[1]);

        for(int i=2;i<3;i++)
            list.add(parts[2]); */


        adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        /*adapter1 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);*/


        spinner.setAdapter(adapter);

        // spinner2.setAdapter(adapter1);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {

                types = spinner.getSelectedItem().toString();
                // Toast.makeText(getApplicationContext(), types, Toast.LENGTH_LONG).show();


                try {
                    getitems();
                } catch (Exception e) {
                }

                //String items=spinner2.getSelectedItem().toString();
                //Toast.makeText(getApplicationContext(), items, Toast.LENGTH_LONG).show();
                // Log.i("Selected item : ", items);
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {

            }

        });

    }


    private void getitems() throws InterruptedException {


        // Connect with a server is a time consuming process.
        //Therefore we use AsyncTask to handle it
        // From the three generic types;
        //First type relate with the argument send in execute()
        //Second type relate with onProgressUpdate method which I haven't use in this code
        //Third type relate with the return type of the doInBackground method, which also the input type of the onPostExecute method
        class HttpGetAsyncTask extends AsyncTask<String, Void, String> {


            @Override
            protected String doInBackground(String... params) {

                // As you can see, doInBackground has taken an Array of Strings as the argument
                //We need to specifically get the givenUsername and givenPassword

                // Create an intermediate to connect with the Internet
                //HttpClient httpClient = new DefaultHttpClient();

                // Sending a GET request to the web page that we want
                // Because of we are sending a GET request, we have to pass the values through the URL
                //HttpGet httpGet = new HttpGet("http://jnnce.ac.in/cse/atd.php");


                try {
                    String link = "http://mwallete.esy.es/wallette/sgettypes.php";
                    //Toast.makeText(getApplicationContext(), v.toString(),Toast.LENGTH_LONG).show();


                    //e1=(EditText)findViewById(R.id.editText);

                    String data = "type=" + types;
                    // String data="usn=as0ed";
                    // "&branch="+branch+"&email="+email+"&pno="+pno+"&sem="+sem;
                    //Toast.makeText(getApplicationContext(),data,Toast.LENGTH_LONG).show();
                    //txtLat=(TextView) findViewById(R.id.textview1);
                    //txtLat.setText(link);
                    URL url = new URL(link);
                    URLConnection conn = url.openConnection();
                    conn.setDoOutput(true);

                    OutputStreamWriter wr = new OutputStreamWriter
                            (conn.getOutputStream());
                    wr.write(data);
                    wr.flush();

                    BufferedReader reader = new BufferedReader
                            (new InputStreamReader(conn.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line = null;
                    // Read Server Response
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();


                } catch (ClientProtocolException cpe) {
                    System.out.println("Exceptionrates caz of httpResponse :" + cpe);
                    s = "e1";
                    cpe.printStackTrace();
                    //  Toast.makeText(getApplicationContext(), cpe.toString(),Toast.LENGTH_LONG).show();
                } catch (IOException ioe) {
                    System.out.println("Secondption generates caz of httpResponse :" + ioe);
                    s = ioe.toString();
                    ioe.printStackTrace();
//                    Toast.makeText(getApplicationContext(), ioe.toString(),Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    //Toast.makeText(getApplicationContext(), e.toString(),Toast.LENGTH_LONG).show();
                }

                return s;
            }

            // Argument comes for this method according to the return type of the doInBackground() and
            //it is the third generic type of the AsyncTask
            @Override
            protected void onPostExecute(String result) {
                super.onPostExecute(result);
                //if(result.length()>0)
                s = result;

                //Toast.makeText(getApplicationContext(), "HTTP GET is working...", Toast.LENGTH_LONG).show();
                sorderActivity.this.donext2();
                //orderActivity.this.donext1();
			/*	if(result.equals("working")){
					Toast.makeText(getApplicationContext(), "HTTP GET is working...", Toast.LENGTH_LONG).show();
				}else{
					Toast.makeText(getApplicationContext(), "Invalid...", Toast.LENGTH_LONG).show();
				}	*/
            }
        }

        // Initialize the AsyncTask class
        try {
            HttpGetAsyncTask httpGetAsyncTask = new HttpGetAsyncTask();
            // Parameter we pass in the execute() method is relate to the first generic type of the AsyncTask
            // We are passing the connectWithHttpGet() method arguments to that
            httpGetAsyncTask.execute();
        } catch (Exception e) {
            //t1 = (TextView) findViewById(R.id.t1);
            //t1.setText(e.toString());
            Toast.makeText(getApplicationContext(), "ss", Toast.LENGTH_LONG).show();
        }

    }

    public void donext2() {

        // Toast.makeText(getApplicationContext(),s, Toast.LENGTH_LONG).show();
        spinner2 = (Spinner) findViewById(R.id.spinner2);
        // spinner2 = (Spinner) findViewById(R.id.spinner2);
        ArrayAdapter<String> adapter2;
        List<String> list2;

        list2 = new ArrayList<String>();
        String parts2[] = s.split("#");
        for (int i = 0; i < parts2.length; i++)
            list2.add(parts2[i]);


        adapter2 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list2);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        /*adapter1 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);*/


        spinner2.setAdapter(adapter2);

        // spinner2.setAdapter(adapter1);

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {

                String items = spinner2.getSelectedItem().toString();
                //Toast.makeText(getApplicationContext(), items, Toast.LENGTH_LONG).show();





            }



            @Override
            public void onNothingSelected(AdapterView<?> arg0) {

            }

        });




    }


    private void submit() throws InterruptedException {



       /* Button b8 =(Button)findViewById(R.id.button8);

        b8.setText("Submit");
        linearMain.addView(b8);
        b8.setOnClickListener(getOnClickDoSomething(b8));*/


        // Connect with a server is a time consuming process.
        //Therefore we use AsyncTask to handle it
        // From the three generic types;
        //First type relate with the argument send in execute()
        //Second type relate with onProgressUpdate method which I haven't use in this code
        //Third type relate with the return type of the doInBackground method, which also the input type of the onPostExecute method
        class HttpGetAsyncTask extends AsyncTask<String, Void, String> {


            @Override
            protected String doInBackground(String... params) {

                // As you can see, doInBackground has taken an Array of Strings as the argument
                //We need to specifically get the givenUsername and givenPassword

                // Create an intermediate to connect with the Internet
                //HttpClient httpClient = new DefaultHttpClient();

                // Sending a GET request to the web page that we want
                // Because of we are sending a GET request, we have to pass the values through the URL
                //HttpGet httpGet = new HttpGet("http://jnnce.ac.in/cse/atd.php");


                try {

                    //types=e7.getText().toString();
                    types = spinner.getSelectedItem().toString();
                    items = spinner2.getSelectedItem().toString();

                    //t1=(TextView)findViewById(R.id.textView13);
                    //    datas=t1.getText().toString();
                    String data="usn="+usn+"&datas=";
                    for(int i=0;i<ocnt;i++)
                    {
                        if(checkBox[i].isChecked()) {
                            data=data+itstr[i];
                        }

                    }

                    //String data  = "&usn="+usn+"&types="+types+"&items="+items;
                    //String datas1="&datas="+datas;
                    String link = "http://mwallete.esy.es/wallette/spayfeesc.php";

                    //txtView.setText(txtView.getText().toString()+" " +add_items+" "+add_items2+" "+add_quantity.getText().toString());
                    //Toast.makeText(getApplicationContext(), v.toString(),Toast.LENGTH_LONG).show()
                    // String data="usn=as0ed";
                    // "&branch="+branch+"&email="+email+"&pno="+pno+"&sem="+sem;
                    //Toast.makeText(getApplicationContext(),data,Toast.LENGTH_LONG).show();
                    //txtLat=(TextView) findViewById(R.id.textview1);
                    //txtLat.setText(link);
                    URL url = new URL(link);
                    URLConnection conn = url.openConnection();
                    conn.setDoOutput(true);

                    OutputStreamWriter wr = new OutputStreamWriter
                            (conn.getOutputStream());
                    wr.write(data);
                    wr.flush();

                    BufferedReader reader = new BufferedReader
                            (new InputStreamReader(conn.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line = null;
                    // Read Server Response
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();


                } catch (ClientProtocolException cpe) {
                    System.out.println("Exceptionrates caz of httpResponse :" + cpe);
                    s = "e1";
                    cpe.printStackTrace();
                    //  Toast.makeText(getApplicationContext(), cpe.toString(),Toast.LENGTH_LONG).show();
                } catch (IOException ioe) {
                    System.out.println("Secondption generates caz of httpResponse :" + ioe);
                    s = ioe.toString();
                    ioe.printStackTrace();
//                    Toast.makeText(getApplicationContext(), ioe.toString(),Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    //Toast.makeText(getApplicationContext(), e.toString(),Toast.LENGTH_LONG).show();
                }

                return s;
            }

            // Argument comes for this method according to the return type of the doInBackground() and
            //it is the third generic type of the AsyncTask
            @Override
            protected void onPostExecute(String result) {
                super.onPostExecute(result);
                //if(result.length()>0)
                s = result;

                //Toast.makeText(getApplicationContext(), "HTTP GET is working...", Toast.LENGTH_LONG).show();
                sorderActivity.this.dolast();
               /* try {

                    recieveOTP();
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }*/

			/*	if(result.equals("working")){
					Toast.makeText(getApplicationContext(), "HTTP GET is working...", Toast.LENGTH_LONG).show();
				}else{
					Toast.makeText(getApplicationContext(), "Invalid...", Toast.LENGTH_LONG).show();
				}	*/
            }
        }

        // Initialize the AsyncTask class
        try {
            HttpGetAsyncTask httpGetAsyncTask = new HttpGetAsyncTask();
            // Parameter we pass in the execute() method is relate to the first generic type of the AsyncTask
            // We are passing the connectWithHttpGet() method arguments to that
            httpGetAsyncTask.execute();
        } catch (Exception e) {
            //t1 = (TextView) findViewById(R.id.t1);
            //t1.setText(e.toString());
            Toast.makeText(getApplicationContext(), "ss", Toast.LENGTH_LONG).show();
        }

    }
    public void dolast()
    {

        Toast.makeText(getApplicationContext(),s, Toast.LENGTH_LONG).show();
       /* Intent intent = new Intent(getApplicationContext(), orderActivity.class);
        intent.putExtra("types",types);
        intent.putExtra("items",items);
        startActivity(intent);*/
    }



    private void recieveOTP() throws InterruptedException {


        // Connect with a server is a time consuming process.
        //Therefore we use AsyncTask to handle it
        // From the three generic types;
        //First type relate with the argument send in execute()
        //Second type relate with onProgressUpdate method which I haven't use in this code
        //Third type relate with the return type of the doInBackground method, which also the input type of the onPostExecute method
        class HttpGetAsyncTask extends AsyncTask<String, Void, String>{



            @Override
            protected String doInBackground(String... params) {

                // As you can see, doInBackground has taken an Array of Strings as the argument
                //We need to specifically get the givenUsername and givenPassword

                // Create an intermediate to connect with the Internet
                //HttpClient httpClient = new DefaultHttpClient();

                // Sending a GET request to the web page that we want
                // Because of we are sending a GET request, we have to pass the values through the URL
                //HttpGet httpGet = new HttpGet("http://jnnce.ac.in/cse/atd.php");

                try {
                    // execute(); executes a request using the default context.
                    // Then we assign the execution result to HttpResponse
					/*HttpResponse httpResponse = httpClient.execute(httpGet);

					// getContent() ; creates a new InputStream object of the entity.
					// Now we need a readable source to read the byte stream that comes as the httpResponse
					InputStream inputStream = httpResponse.getEntity().getContent();

					// We have a byte stream. Next step is to convert it to a Character stream
					InputStreamReader inputStreamReader = new InputStreamReader(inputStream);

					// Then we have to wraps the existing reader (InputStreamReader) and buffer the input
					BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

					// InputStreamReader contains a buffer of bytes read from the source stream and converts these into characters as needed.
					//The buffer size is 8K
					//Therefore we need a mechanism to append the separately coming chunks in to one String element
					// We have to use a class that can handle modifiable sequence of characters for use in creating String
					StringBuilder stringBuilder = new StringBuilder();

					String bufferedStrChunk = null;

					// There may be so many buffered chunks. We have to go through each and every chunk of characters
					//and assign a each chunk to bufferedStrChunk String variable
					//and append that value one by one to the stringBuilder
					while((bufferedStrChunk = bufferedReader.readLine()) != null){
						stringBuilder.append(bufferedStrChunk);
					}

					// Now we have the whole response as a String value.
					//We return that value then the onPostExecute() can handle the content
					System.out.println("Returninge of doInBackground :" + stringBuilder.toString());
                     s=stringBuilder.toString();

					//s=
					//tv.setText(stringBuilder.toString());

					return stringBuilder.toString();*/
                    String link="http://mwallete.esy.es/wallette/recvotp.php";
                    String data  = "";
                    URL url = new URL(link);
                    sd=usn;
                    URLConnection conn = url.openConnection();
                    conn.setDoOutput(true);
                    OutputStreamWriter wr = new OutputStreamWriter
                            (conn.getOutputStream());
                    wr.write("data="+usn );
                    wr.flush();
                    BufferedReader reader = new BufferedReader
                            (new InputStreamReader(conn.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line = null;
                    // Read Server Response
                    while((line = reader.readLine()) != null)
                    {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();

                } catch (ClientProtocolException cpe) {
                    System.out.println("Exceptionrates caz of httpResponse :" + cpe);
                    s="e1";
                    cpe.printStackTrace();
                } catch (IOException ioe) {
                    System.out.println("Secondption generates caz of httpResponse :" + ioe);
                    s=ioe.toString();
                    ioe.printStackTrace();
                }

                return s;
            }

            // Argument comes for this method according to the return type of the doInBackground() and
            //it is the third generic type of the AsyncTask
            @Override
            protected void onPostExecute(String result) {
                super.onPostExecute(result);
                s=result;

                sorderActivity.this.rotp();
			/*	if(result.equals("working")){
					Toast.makeText(getApplicationContext(), "HTTP GET is working...", Toast.LENGTH_LONG).show();
				}else{
					Toast.makeText(getApplicationContext(), "Invalid...", Toast.LENGTH_LONG).show();
				}	*/
            }
        }

        // Initialize the AsyncTask class
        HttpGetAsyncTask httpGetAsyncTask = new HttpGetAsyncTask();
        // Parameter we pass in the execute() method is relate to the first generic type of the AsyncTask
        // We are passing the connectWithHttpGet() method arguments to that
        httpGetAsyncTask.execute();

    }

    public  void rotp()
    {
          Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Enter OTP");

// Set up the input
        final EditText input = new EditText(this);
// Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        builder.setView(input);

// Set up the buttons
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String  m_Text = input.getText().toString();
                if(m_Text.equals(s)) {
                    Toast.makeText(getApplicationContext(), "correct", Toast.LENGTH_LONG).show();

                    try {
                        submit();
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
                else
                    Toast.makeText(getApplicationContext(), "incorrect", Toast.LENGTH_LONG).show();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }


    private void sendAttendance() throws InterruptedException {


        // Connect with a server is a time consuming process.
        //Therefore we use AsyncTask to handle it
        // From the three generic types;
        //First type relate with the argument send in execute()
        //Second type relate with onProgressUpdate method which I haven't use in this code
        //Third type relate with the return type of the doInBackground method, which also the input type of the onPostExecute method
        class HttpGetAsyncTask extends AsyncTask<String, Void, String>{



            @Override
            protected String doInBackground(String... params) {


                try {


                    String link="http://mwallete.esy.es/wallette/spayfeesc.php";
                    String data  = "";
                    URL url = new URL(link);
                    URLConnection conn = url.openConnection();
                    conn.setDoOutput(true);
                    OutputStreamWriter wr = new OutputStreamWriter
                            (conn.getOutputStream());
                    wr.write("data="+sd );
                    wr.flush();
                    BufferedReader reader = new BufferedReader
                            (new InputStreamReader(conn.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line = null;
                    // Read Server Response
                    while((line = reader.readLine()) != null)
                    {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();

                } catch (ClientProtocolException cpe) {
                    System.out.println("Exceptionrates caz of httpResponse :" + cpe);
                    s="e1";
                    cpe.printStackTrace();
                } catch (IOException ioe) {
                    System.out.println("Secondption generates caz of httpResponse :" + ioe);
                    s=ioe.toString();
                    ioe.printStackTrace();
                }

                return s;
            }

            // Argument comes for this method according to the return type of the doInBackground() and
            //it is the third generic type of the AsyncTask
            @Override
            protected void onPostExecute(String result) {
                super.onPostExecute(result);
                s=result;

                sorderActivity.this.dolast();
			/*	if(result.equals("working")){
					Toast.makeText(getApplicationContext(), "HTTP GET is working...", Toast.LENGTH_LONG).show();
				}else{
					Toast.makeText(getApplicationContext(), "Invalid...", Toast.LENGTH_LONG).show();
				}	*/
            }
        }

        // Initialize the AsyncTask class
        HttpGetAsyncTask httpGetAsyncTask = new HttpGetAsyncTask();
        // Parameter we pass in the execute() method is relate to the first generic type of the AsyncTask
        // We are passing the connectWithHttpGet() method arguments to that
        httpGetAsyncTask.execute();

    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_sorder, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
